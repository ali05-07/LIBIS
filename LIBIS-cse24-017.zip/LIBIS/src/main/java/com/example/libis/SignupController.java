package com.example.libis;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/signup")
public class SignupController extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("/WEB-INF/signup.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String firstName = trim(request.getParameter("firstname"));
        String lastName = trim(request.getParameter("lastname"));
        String email = trim(request.getParameter("email"));
        String password = request.getParameter("password");

        if (firstName.isEmpty() || lastName.isEmpty() || email.isEmpty() || password == null || password.isEmpty()) {
            request.setAttribute("errorMessage", "Please complete all fields.");
            showSignup(request, response);
            return;
        }

        List<member> members = getMembers();
        boolean emailAlreadyRegistered = false;
        boolean passwordAlreadyRegistered = false;
        synchronized (members) {
            for (member existingMember : members) {
                if (email.equalsIgnoreCase(existingMember.getEmail())) {
                    emailAlreadyRegistered = true;
                }
                if (password.equals(existingMember.getPassword())) {
                    passwordAlreadyRegistered = true;
                }
            }

            if (!emailAlreadyRegistered && !passwordAlreadyRegistered) {
                int nextId = 1;
                for (member existingMember : members) {
                    nextId = Math.max(nextId, existingMember.getMemberID() + 1);
                }
                members.add(new member(nextId, firstName, lastName, email, password));
            }
        }

        if (emailAlreadyRegistered || passwordAlreadyRegistered) {
            request.setAttribute("errorMessage", "That email or password is already being used.");
            showSignup(request, response);
            return;
        }

        response.sendRedirect(request.getContextPath() + "/index.jsp?registered=true");
    }

    @SuppressWarnings("unchecked")
    private List<member> getMembers() {
        synchronized (getServletContext()) {
            Object currentMembers = getServletContext().getAttribute("members");
            if (currentMembers instanceof List<?>) {
                return (List<member>) currentMembers;
            }

            List<member> members = new ArrayList<>();
            members.add(new member(1, "Bill", "Warren", "wax@gmail.com", "123"));
            members.add(new member(2, "Lily", "Swapi", "swa@gmail.com", "987"));
            members.add(new member(3, "Kelly", "Jellow", "jell@gmail.com", "abc"));
            members.add(new member(4, "Zeth", "Kanye", "kan@gmail.com", "zee"));
            members.add(new member(5, "Gomolemo", "Milo", "gomo@gmail.com", "gee"));
            getServletContext().setAttribute("members", members);
            return members;
        }
    }

    private String trim(String value) {
        return value == null ? "" : value.trim();
    }

    private void showSignup(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("/WEB-INF/signup.jsp").forward(request, response);
    }
}
