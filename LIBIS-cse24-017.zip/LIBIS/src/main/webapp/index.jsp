<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
<head>
  <title>LIBIS-Login</title>
 <style>
 body {
     font-family: Arial;
     background: #ffffff;
     padding: 20px;
 }
 form {
     background: gray;
     padding: 30px;
     max-width: 350px;
     margin: 0 auto;
     border-radius: 8px;
 }
 input[type="email"], input[type="password"] {
     width: 100%;
     padding: 8px;
     margin: 5px 0 15px 0;
 }
 input[type="submit"], button {
     background: #000000;
     color: white;
     padding: 10px 20px;
     border: none;
     border-radius: 4px;
     cursor: pointer;
 }
 .message {
     max-width: 350px;
     margin: 12px auto;
 }
 .signup-prompt {
     margin: 20px 0 0;
     text-align: center;
 }
 .signup-prompt a {
     color: #000000;
     font-weight: bold;
     text-decoration: none;
 }
 .signup-prompt a:hover,
 .signup-prompt a:focus {
     text-decoration: underline;
 }
 </style>
</head>

<body>

<c:choose>
  <c:when test="${param.registered eq 'true'}">
    <p class="message" style="color: green;">Account created. You can now log in.</p>
  </c:when>
  <c:when test="${param.error eq 'invalid'}">
    <p class="message" style="color: red;">Invalid email or password.</p>
  </c:when>
</c:choose>

<form action="${pageContext.request.contextPath}/login" method="post">
 <h2>LOGIN</h2>
<label for="username">Email:</label>
<input type="email" id="username" name="username" required>

<label for="password">Password:</label>
<input type="password" id="password" name="password" required>

<button type="submit">Login</button>
<p class="signup-prompt">Not registered yet? <a href="${pageContext.request.contextPath}/signup">Sign up here</a></p>

</form>

</body>
</html>
