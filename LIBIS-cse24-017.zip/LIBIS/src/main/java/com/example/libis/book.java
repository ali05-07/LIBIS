package com.example.libis;

public class book {

    private int bookID;
    private String title;
    private String author;
    private String genre;
    private String synopsis;
    private boolean available;

    public book(int bookID, String title, String author,
                String genre, String synopsis, boolean available) {

        this.bookID = bookID;
        this.title = title;
        this.author = author;
        this.genre = genre;
        this.synopsis = synopsis;
        this.available = available;
    }

    public int getBookID() {
        return bookID;
    }

    public void setBookID(int bookID) {
        this.bookID = bookID;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public String getSynopsis() {
        return synopsis;
    }

    public void setSynopsis(String synopsis) {
        this.synopsis = synopsis;
    }

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }
}
