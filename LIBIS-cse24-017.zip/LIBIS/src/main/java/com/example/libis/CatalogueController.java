package com.example.libis;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

@WebServlet("/catalogue")
public class CatalogueController extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Object catalogue = getServletContext().getAttribute("books");
        List<book> allBooks = new ArrayList<>();
        if (catalogue instanceof List<?>) {
            for (Object item : (List<?>) catalogue) {
                if (item instanceof book) {
                    allBooks.add((book) item);
                }
            }
        }

        String searchTerm = request.getParameter("search");
        List<book> filteredBooks = new ArrayList<>();
        if (searchTerm == null || searchTerm.trim().isEmpty()) {
            filteredBooks.addAll(allBooks);
        } else {
            String search = searchTerm.trim().toLowerCase(Locale.ROOT);
            for (book item : allBooks) {
                if (containsIgnoreCase(item.getTitle(), search)
                        || containsIgnoreCase(item.getAuthor(), search)
                        || containsIgnoreCase(item.getGenre(), search)) {
                    filteredBooks.add(item);
                }
            }
        }

        request.setAttribute("books", filteredBooks);
        request.getRequestDispatcher("/WEB-INF/welcome.jsp").forward(request, response);
    }

    private boolean containsIgnoreCase(String value, String search) {
        return value != null && value.toLowerCase(Locale.ROOT).contains(search);
    }
}
