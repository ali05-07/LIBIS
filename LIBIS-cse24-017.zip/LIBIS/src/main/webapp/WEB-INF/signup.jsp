<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
<head>
    <title>Signup</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #ffffff;
            padding: 20px;
        }

        form {
            background: gray;
            padding: 30px;
            max-width: 350px;
            margin: 0 auto;
            border-radius: 8px;
        }

        input[type="text"], input[type="email"], input[type="password"] {
            box-sizing: border-box;
            width: 100%;
            padding: 8px;
            margin: 5px 0 15px;
        }

        button {
            background: #000000;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .message {
            color: #842029;
            background-color: #f8d7da;
            border: 1px solid #f1aeb5;
            border-radius: 4px;
            padding: 10px 12px;
            margin: 0 0 15px;
        }

        .login-prompt {
            margin: 20px 0 0;
            text-align: center;
        }

        .login-prompt a {
            color: #000000;
            font-weight: bold;
            text-decoration: none;
        }

        .login-prompt a:hover,
        .login-prompt a:focus {
            text-decoration: underline;
        }
    </style>
</head>
<body>
<form action="${pageContext.request.contextPath}/signup" method="post">
    <h2>SIGNUP</h2>
    <c:if test="${not empty errorMessage}">
        <p class="message"><c:out value="${errorMessage}"/></p>
    </c:if>
    <label for="firstname">First Name:</label>
    <input type="text" id="firstname" name="firstname" value="<c:out value='${param.firstname}'/>" required>

    <label for="lastname">Last Name:</label>
    <input type="text" id="lastname" name="lastname" value="<c:out value='${param.lastname}'/>" required>

    <label for="email">Email:</label>
    <input type="email" id="email" name="email" value="<c:out value='${param.email}'/>" required>

    <label for="password">Password:</label>
    <input type="password" id="password" name="password" required>

    <button type="submit">Signup</button>
    <p class="login-prompt">Already registered? <a href="${pageContext.request.contextPath}/index.jsp">Login here</a></p>
</form>
<script>
    const form = document.querySelector("form");
    const errorMessage = document.querySelector(".message");

    if (form && errorMessage) {
        form.addEventListener("input", () => {
            errorMessage.hidden = true;
        });
    }
</script>
</body>
</html>
