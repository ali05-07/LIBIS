<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><c:out value="${selectedBook.title}"/> - LIBIS</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #fffdd0;
            margin: 20px;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            padding: 24px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            color: #1e1b4b;
        }

        .book-info {
            color: #555;
            line-height: 1.6;
        }

        .back-link {
            display: inline-block;
            margin-top: 16px;
            color: #1e1b4b;
        }
    </style>
</head>
<body>
<main class="container">
    <h1><c:out value="${selectedBook.title}"/></h1>
    <div class="book-info">
        <p><strong>Author:</strong> <c:out value="${selectedBook.author}"/></p>
        <p><strong>Genre:</strong> <c:out value="${selectedBook.genre}"/></p>
        <p><strong>Synopsis:</strong> <c:out value="${selectedBook.synopsis}" default="No synopsis available."/></p>
    </div>
    <a class="back-link" href="${pageContext.request.contextPath}/catalogue">Back to catalogue</a>
</main>
</body>
</html>
