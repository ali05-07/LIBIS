package com.example.libis;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

@WebServlet("/book")
public class BookServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        if (request.getSession(false) == null || request.getSession(false).getAttribute("loggedInMember") == null) {
            response.sendRedirect(request.getContextPath() + "/index.jsp");
            return;
        }

        int bookId;
        try {
            bookId = Integer.parseInt(request.getParameter("id"));
        } catch (NumberFormatException e) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
            return;
        }

        Object catalogue = getServletContext().getAttribute("books");
        if (!(catalogue instanceof List<?>)) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
            return;
        }

        book selectedBook = null;
        for (Object item : (List<?>) catalogue) {
            if (item instanceof book && ((book) item).getBookID() == bookId) {
                selectedBook = (book) item;
                break;
            }
        }

        if (selectedBook == null) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
            return;
        }

        request.setAttribute("selectedBook", selectedBook);
        request.getRequestDispatcher("/WEB-INF/book-details.jsp").forward(request, response);
    }
}
