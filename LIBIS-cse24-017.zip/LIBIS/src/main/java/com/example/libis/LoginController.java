package com.example.libis;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet(name = "LoginServlet", value = "/login")
public class LoginController extends HttpServlet {
    private List<member> users;
    public void init() {
        synchronized (getServletContext()) {
            Object existingMembers = getServletContext().getAttribute("members");
            if (existingMembers instanceof List<?>) {
                users = (List<member>) existingMembers;
            } else {
                users = new ArrayList<>();
                users.add(new member(1, "Bill", "Warren", "wax@gmail.com", "123"));
                users.add(new member(2, "Lily", "Swapi", "swa@gmail.com", "987"));
                users.add(new member(3, "Kelly", "Jellow", "jell@gmail.com", "abc"));
                users.add(new member(4, "Zeth", "Kanye", "kan@gmail.com", "zee"));
                users.add(new member(5, "Gomolemo", "Milo", "gomo@gmail.com", "gee"));
                getServletContext().setAttribute("members", users);
            }
        }
    }
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        if (request.getSession(false) == null || request.getSession(false).getAttribute("loggedInMember") == null) {
            response.sendRedirect(request.getContextPath() + "/index.jsp");
            return;
        }

        response.sendRedirect(request.getContextPath() + "/catalogue");
    }
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html");
        String username = request.getParameter("username");
        if (username == null || username.isEmpty()) {
            username = request.getParameter("email");
        }
        String password = request.getParameter("password");
        member foundMember = null;
        if (username != null && password != null) {
            synchronized (users) {
                for (member user : users) {
                    if (username.equalsIgnoreCase(user.getEmail()) && password.equals(user.getPassword())) {
                        foundMember = user;
                        break;
                    }
                }
            }
        }

        if (foundMember != null) {
            request.getSession().setAttribute("loggedInMember", foundMember);
            if (getServletContext().getAttribute("books") == null) {
                getServletContext().setAttribute("books", createBooks());
            }
            response.sendRedirect(request.getContextPath() + "/catalogue");
            return;
        }

        response.sendRedirect(request.getContextPath() + "/index.jsp?error=invalid");
    }
    private List<book> createBooks() {
        ArrayList<book> books = new ArrayList<book>();
        books.add(new book(1, "Nature", "Collen Young", "Science", "A comprehensive overview of the natural world.", true));
        books.add(new book(2, "Friction", "James Smith", "Fantasy", "A story about the forces that act against motion.", true));
        books.add(new book(3, "Warmth", "Katherine Wood", "InteriorDesign", "Inner feeling of your environment.", false));
        books.add(new book(4, "Abstract", "Barren Livemore", "Art", "A conceptual exploration of abstract ideas.", true));
        books.add(new book(5, "Beyond the Horizon", "Herbert Selmon", "Science", "Exploring the limits of human knowledge.", true));
        books.add(new book(6, "Express", "Emma Ash", "Poetry", "A collection of poems exploring the nature of expression.", true));
        books.add(new book(7, "Salute", "Sara Mitten", "Art", "A tribute to the power of art.", true));
        books.add(new book(8, "The One Eyed", "Carmen Silver", "Fantasy", "A tale of a mysterious one-eyed character.", true));
        books.add(new book(9, "Reprecussions", "Riley Mathew", "Poetry", "Consequences of our actions.", true));
        books.add(new book(10, "The Collectives", "Pharell Williams", "Art", "A collection of artworks by various artists.", true));
        return books;
    }

    public void destroy() {
    }
}
