<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>LIBIS - Book Catalogue</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #fffdd0;
            margin: 20px;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 2px solid #ffbe98;
            padding-bottom: 15px;
            margin-bottom: 20px;
        }

        .header h1 {
            color: #9caf88;
            margin: 0;
        }

        .header h1 span {
            color: #ffaa00;
        }

        .welcome-message {
            font-size: 18px;
            color: #34495e;
        }

        .welcome-message strong {
            color: #2c3e50;
        }

        .logout-link {
            color: #e74c3c;
            text-decoration: none;
            font-weight: bold;
            margin-left: 15px;
        }

        .logout-link:hover {
            text-decoration: underline;
        }

        .book-count {
            color: #7f8c8d;
            font-size: 14px;
            margin-bottom: 15px;
        }

        .search-form {
            display: flex;
            align-items: center;
            flex-wrap: wrap;
            gap: 8px;
            margin: 20px 0 24px;
        }

        .search-form input {
            padding: 8px 10px;
            min-width: 240px;
        }

        .search-form button {
            padding: 8px 14px;
            cursor: pointer;
        }

        .search-form .clear-button {
            background: #6c757d;
            color: white;
            border: 0;
            border-radius: 4px;
            padding: 8px 14px;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            background-color: #2c3e50;
            color: white;
            padding: 12px;
            text-align: left;
            font-weight: bold;
        }

        td {
            padding: 10px 12px;
            border-bottom: 1px solid #ddd;
        }

        .book-title {
            color: #1e1b4b;
            text-decoration: none;
        }

        .book-title:hover {
            text-decoration: underline;
        }

        tr:hover {
            background-color: #f5f5f5;
        }

        .available {
            color: #ffaa00;
            font-weight: bold;
        }

        .unavailable {
            color: #000000;
            font-weight: bold;
        }

        .dummy-link {
            color: #1e1b4b;
            text-decoration: none;
            margin-right: 10px;
            padding: 4px 10px;
            border: 1px solid #1e1b4b;
            border-radius: 4px;
            font-size: 12px;
            display: inline-block;
        }

        .dummy-link:hover {
            background-color: #2c3e50;
            color: white;
            text-decoration: none;
        }

        .actions-cell {
            white-space: nowrap;
            min-width: 200px;
        }

        .dummy-note {
            background-color: #f8f9fa;
            border: 1px solid #ddd;
            padding: 10px;
            margin-top: 20px;
            border-radius: 4px;
            color: #6c757d;
            font-size: 13px;
            text-align: center;
        }

        .dummy-note span {
            background-color: #e9ecef;
            padding: 2px 8px;
            border-radius: 3px;
            font-weight: bold;
        }
    </style>
</head>

<body>
<div class="container">
    <div class="header">
        <h1>LIBIS <span>Book Catalogue</span></h1>
        <div class="welcome-message">
            Welcome, <strong><c:out value="${sessionScope.loggedInMember.fullName}" default="Guest"/></strong>
            <a href="${pageContext.request.contextPath}/logout" class="logout-link">Logout</a>
        </div>
    </div>

    <div class="book-count">
        <c:if test="${not empty books}">
            Showing ${books.size()} books in the catalogue
        </c:if>
    </div>

    <form class="search-form" action="${pageContext.request.contextPath}/catalogue" method="get">
        <label for="book-search">Search by title, author, or genre:</label>
        <input type="search" id="book-search" name="search" placeholder="Enter a title, author, or genre..." value="<c:out value='${param.search}'/>">
        <button type="submit">Search</button>
        <a class="clear-button" href="${pageContext.request.contextPath}/catalogue">Clear</a>
    </form>

    <table>
        <thead>
        <tr>
            <th>Title</th>
            <th>Author</th>
            <th>Genre</th>
            <th>Availability</th>
            <th>Actions</th>
        </tr>
        </thead>
        <tbody>
        <c:forEach var="book" items="${books}">
        <tr>
            <td>
                <a class="book-title" href="${pageContext.request.contextPath}/book?id=${book.bookID}">
                    <strong><c:out value="${book.title}"/></strong>
                </a>
            </td>
            <td><c:out value="${book.author}"/></td>
            <td><c:out value="${book.genre}"/></td>
            <td>
                <c:if test="${book.available}">
                <span class="available">Available</span>
                </c:if>
                <c:if test="${not book.available}">
                <span class="unavailable">Borrowed</span>
                </c:if>
            </td>
            <td class="actions-cell">
                <a href="#" class="dummy-link">Borrow</a>
                <a href="#" class="dummy-link">Reserve</a>
            </td>
        </tr>
        </c:forEach>
        </tbody>
    </table>

    </div>
    </body>
    </html>